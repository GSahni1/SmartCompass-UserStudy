using UnityEngine;
using TMPro;
using System;
using System.Collections.Generic;

#if UNITY_ANDROID
using UnityEngine.Android;
#endif

[Serializable]
public class DailyStepData { public string date; public int steps; }

[Serializable]
public class StepDataHistory { public List<DailyStepData> history = new List<DailyStepData>(); }

public class StepCounter : MonoBehaviour
{
    public static StepCounter instance;
    public TextMeshProUGUI stepCountText;

    private long phoneStepsAtDayStart = -1;
    private long lastReceivedTotalSteps = 0;
    
    private StepDataHistory stepHistory = new StepDataHistory();
    private const string StepHistorySaveKey = "StepHistoryData";

    private bool isSensorAvailable = false;
    private AndroidJavaObject stepDetector;

    // --- UNITY LIFECYCLE METHODS ---
    void Awake()
    {
        if (instance == null) { instance = this; DontDestroyOnLoad(gameObject); }
        else { Destroy(gameObject); return; }
    }

    void Start()
    {
        LoadStepData();
        CheckForNewDay();

        #if UNITY_ANDROID && !UNITY_EDITOR
            if (!Permission.HasUserAuthorizedPermission("android.permission.ACTIVITY_RECOGNITION"))
            {
                Permission.RequestUserPermission("android.permission.ACTIVITY_RECOGNITION");
            }
            else { InitializeSensor(); }
        #endif
    }

    void Update()
    {
        if (stepCountText != null)
        {
            DailyStepData todayData = GetTodayStepData();
            stepCountText.text = "Steps Today: " + todayData.steps;
        }

        #if UNITY_ANDROID && !UNITY_EDITOR
        if (!isSensorAvailable && Permission.HasUserAuthorizedPermission("android.permission.ACTIVITY_RECOGNITION"))
        {
            InitializeSensor();
        }
        #endif
    }

    void OnApplicationPause(bool pauseStatus) { if (pauseStatus) { SaveStepData(); } }
    void OnApplicationQuit() { SaveStepData(); }

    // --- SENSOR COMMUNICATION ---
    public void OnStepCounterDataReceived(string message)
    {
        if (long.TryParse(message, out long totalStepsFromPhone))
        {
            if (phoneStepsAtDayStart == -1)
            {
                phoneStepsAtDayStart = totalStepsFromPhone;
                phoneStepsAtDayStart -= GetTodayStepData().steps;
            }
            lastReceivedTotalSteps = totalStepsFromPhone;
            GetTodayStepData().steps = (int)(lastReceivedTotalSteps - phoneStepsAtDayStart);
        }
    }
    
    private void InitializeSensor()
    {
        if(isSensorAvailable) return;
        try
        {
            AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
            AndroidJavaObject currentActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
            AndroidJavaObject sensorManager = currentActivity.Call<AndroidJavaObject>("getSystemService", "sensor");
            int SENSOR_TYPE_STEP_COUNTER = 19;
            AndroidJavaObject sensor = sensorManager.Call<AndroidJavaObject>("getDefaultSensor", SENSOR_TYPE_STEP_COUNTER);

            if (sensor != null)
            {
                stepDetector = new AndroidJavaObject("com.PersuasiveComputing.SmartComp.StepDetectorListener");
                stepDetector.Call("setUnityObjectName", this.gameObject.name);
                stepDetector.Call("register", sensorManager, sensor);
                isSensorAvailable = true; 
            }
        }
        catch (Exception ex) { Debug.LogError("Error initializing Android sensor: " + ex.Message); }
    }

    // --- PRIVATE DATA MANAGEMENT ---
    private void LoadStepData()
    {
        if (PlayerPrefs.HasKey(StepHistorySaveKey))
        {
            stepHistory = JsonUtility.FromJson<StepDataHistory>(PlayerPrefs.GetString(StepHistorySaveKey));
        }
    }

    private void SaveStepData()
    {
        PlayerPrefs.SetString(StepHistorySaveKey, JsonUtility.ToJson(stepHistory));
        PlayerPrefs.Save();
    }

    private void CheckForNewDay()
    {
        string todayDateString = DateTime.Now.ToString("yyyy-MM-dd");
        if (GetTodayStepData().date != todayDateString)
        {
            phoneStepsAtDayStart = -1;
            GetTodayStepData();
        }
    }

    private DailyStepData GetTodayStepData()
    {
        string todayDateString = DateTime.Now.ToString("yyyy-MM-dd");
        foreach (var entry in stepHistory.history)
        {
            if (entry.date == todayDateString) return entry;
        }
        DailyStepData newDayData = new DailyStepData { date = todayDateString, steps = 0 };
        stepHistory.history.Add(newDayData);
        return newDayData;
    }

    // ===================================================================
    // --- PUBLIC API FOR OTHER SCRIPTS ---
    // ===================================================================

    /// <summary>
    /// Returns the number of steps taken during the current day.
    /// </summary>
    public int GetTodaysSteps()
    {
        return GetTodayStepData().steps;
    }

    /// <summary>
    /// Returns the number of steps taken on a specific date.
    /// </summary>
    /// <param name="date">The date string in "yyyy-MM-dd" format.</param>
    public int GetStepsForDate(string date)
    {
        foreach (var entry in stepHistory.history)
        {
            if (entry.date == date)
            {
                return entry.steps;
            }
        }
        return 0; // Return 0 if no data is found for that date.
    }

    /// <summary>
    /// Returns the entire history of daily step data.
    /// </summary>
    public List<DailyStepData> GetEntireHistory()
    {
        return stepHistory.history;
    }
}