using UnityEngine;

public class BuildingManager : MonoBehaviour
{
    public static BuildingManager instance;

    public string CurrentBuildingId { get; private set; } = "";

    void Awake()
    {
        // --- Singleton Pattern ---
        // If an instance already exists and it's not this one, destroy this one.
        if (instance != null && instance != this)
        {
            Destroy(gameObject);
            return;
        }
        // Otherwise, set the instance to this and make it persist across scenes.
        instance = this;
        DontDestroyOnLoad(gameObject);
    }

    /// <summary>
    /// Call this method when MultiSet successfully localizes the user.
    /// </summary>
    /// <param name="buildingId">The Map Code or MapSet Code from the SDK.</param>
    public void SetCurrentBuilding(string buildingId)
    {
        if (!string.IsNullOrEmpty(buildingId))
        {
            CurrentBuildingId = buildingId;
            Debug.Log("Building context updated to: " + CurrentBuildingId);
        }
        else
        {
            Debug.LogWarning("Attempted to set an invalid building ID.");
        }
    }
}